package com.app.customException;

public class WeddingOrgException extends RuntimeException{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WeddingOrgException(String msg) {
    	super(msg);
    }
}
