package com.app.pojos;

public enum Roles {
	ADMIN,CUSTOMER

}
