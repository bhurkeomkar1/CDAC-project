package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.bookingRepository;
import com.app.pojos.Booking;
import com.app.pojos.User;
@Service
@Transactional
public class BookingServiceImpl implements IBookingService{
	
	

	

}
