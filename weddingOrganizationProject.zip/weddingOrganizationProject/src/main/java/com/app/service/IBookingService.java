package com.app.service;

import com.app.pojos.Booking;
import com.app.pojos.User;

public interface IBookingService {
	//Booking save(User user);

}
